package com.food_on.app;

public class User  {

    String Role;

    public User(String role)
    {
        Role=role;
    }
}
