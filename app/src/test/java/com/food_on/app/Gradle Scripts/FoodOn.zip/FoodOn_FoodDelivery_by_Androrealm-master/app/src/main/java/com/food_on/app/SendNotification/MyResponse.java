package com.food_on.app.SendNotification;

public class MyResponse {

    public int success;
}
